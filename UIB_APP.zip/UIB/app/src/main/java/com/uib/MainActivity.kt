package com.uib

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentTransaction
import com.unified.inbox.UIBChatFragment
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // val
        //supportActionBar?.hide()
        supportActionBar?.title = "UIB"
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        if (supportFragmentManager.findFragmentByTag("TAG") != null) {
            btnSupport.visibility = View.GONE
            val fragment: UIBChatFragment =
                supportFragmentManager.findFragmentByTag("TAG") as UIBChatFragment
            val fragmentTransaction: FragmentTransaction =
                supportFragmentManager.beginTransaction()
            fragmentTransaction.replace(
                R.id.content,
                fragment,
                "TAG"
            )
            //if (backSack) {
            fragmentTransaction.addToBackStack("TAG")
            //}
            fragmentTransaction.commit()
        }
        btnSupport.setOnClickListener {
            btnSupport.visibility = View.GONE
            //supportActionBar?.hide()
            val mFragment = UIBChatFragment()
            mFragment.shouldShowErrorForEmptyMessage(value = true)
            mFragment.showErrorMessageForEmptyValue(
                "Type here..."
            )
           // mFragment.setUIBEditTextHint("Type here...")
            mFragment.setAccountDetails(
                appId = "c9e0faed-0d1c-4580-a118-ad017811688a",
                botId = "123456",
                userId = "5e71ba3ba4c44a0e9f60854e"
            )
            mFragment.retainInstance = true
            mFragment.trimTypedMessage(value = true)
            mFragment.setNoDataTextVisibility(View.VISIBLE)
            mFragment.setNoDataText(
                resources?.getString(R.string.no_data_found)!!,
                resources.getColor(R.color.gray),
                Typeface.NORMAL,
                20.0f
            )

            /*mFragment.setMarginForUserText(
                adjustMargin = true,
                left = 125,
                right = 125,
                top = 125,
                bottom = 125
            )
            mFragment.setPaddingForUserText(
                adjustPadding = true,
                left = 125,
                right = 125,
                top = 125,
                bottom = 125
            )*/
            //mFragment.setUserMessageTextColor(resources.getColor(R.color.colorPrimary))
            //mFragment.setSupportMessageTextBackground(resources.getDrawable(R.drawable.screen_background))
            //mFragment.setSupportMessageTextColor(resources.getColor(R.color.white))
            //mFragment.setUIBEditTextBackground(resources.getDrawable(R.drawable.edit_text_background_client))
            //mFragment.setUIBEditTextHintColor(resources.getColor(R.color.colorPrimary))
            //mFragment.setUIBSendButtonBackground(resources.getDrawable(R.drawable.screen_background))
            //mFragment.setUIBSendIcon(resources.getDrawable(R.drawable.ic_trending_up_black_24dp))
            //mFragment.setUserMessageTextSize(20.0f)
            //mFragment.setBackGroundForLayout(getDrawable(R.drawable.screen_background)!!)
            /* mFragment.setMarginForEditText(
             left = 25,
             right = 25,
             adjustMargin = true,
             top = 25,
             bottom = 50

         )*/
            //mFragment.setUIBEditTextHintColor(R.color.colorPrimary)
            //mFragment.showErrorMessageForEmptyValue(errorString = "Bhaskar Pasupula")
            // mFragment.setUIBEditTextHint("Hello type your message here")
            //mFragment.setPaddingForEditText(left = 10, right = 10, top = 10, bottom = 10)
            // mFragment.setUIBActionBarTitle("AMT")
            val fragmentTransaction: FragmentTransaction =
                supportFragmentManager.beginTransaction()
            fragmentTransaction.replace(
                R.id.content,
                mFragment,
                "TAG"
            )
            //if (backSack) {
            fragmentTransaction.addToBackStack("TAG")
            //}
            fragmentTransaction.commit()


        }

    }

    override fun onStart() {
        super.onStart()
        //btnSupport.visibility = View.VISIBLE
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.sample_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.change_language) {
            //var lang: String?
            val lang = if (resources.configuration.locale.language == "ar") {
                "en"
            } else {
                "ar"
            }
            val locale = Locale(lang)
            Locale.setDefault(locale)
            val config = Configuration()
            config.locale = locale
            onConfigurationChanged(config)
            baseContext.resources.updateConfiguration(
                config,
                baseContext.resources.displayMetrics
            )
            this.finish()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        return true
    }


    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
}
