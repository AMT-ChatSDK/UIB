package com.unified.inbox

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import java.util.*

class UIBChatFragment : Fragment(), UIBListener, UIBEditTextListener, View.OnClickListener,
    OnResponseListener, UIBEventListener {
    private var mView: View? = null
    private var etMessage: EditText? = null
    private var tvNoData: TextView? = null
    private var hint: String? = null
    private var sendIcon: Drawable? = null
    private var sendButtonBackground: Drawable? = null
    private var editTextBackground: Drawable? = null
    private var layoutBackground: Drawable? = null
    private var editTextInputType: Int? = null
    private var editTextRightPadding: Int? = 0

    //private var editTextContainerRightPadding: Int? = 0
    private var editTextLeftPadding: Int? = 0

    //private var editTextContainerLeftPadding: Int? = 0
    private var editTextTopPadding: Int? = 0

    //private var editTextContainerTopPadding: Int? = 0
    private var editTextBottomPadding: Int? = 0

    //private var editTextContainerBottomPadding: Int? = 0
    private var editTextBottomMargin: Int? = 0

    //private var editTextContainerBottomMargin: Int? = 0
    private var editTextTopMargin: Int? = 0

    //private var editTextContainerTopMargin: Int? = 0
    private var editTextLeftMargin: Int? = 0

    //private var editTextContainerLeftMargin: Int? = 0
    private var editTextRightMargin: Int? = 0

    //private var editTextContainerRightMargin: Int? = 0
    private var actionBarTitle: String? = null
    private var tvUserMessage: TextView? = null
    private var tvBotMessage: TextView? = null
    private var sendMessage: TextView? = null
    private var errorMessage: String? = null
    private var shouldShowErrorMessage: Boolean? = true
    private var trimTypedMessage: Boolean? = false
    private var rvChatList: RecyclerView? = null
    private var editTextHintColor: Int? = null
    private var adjustEditTextPadding: Boolean? = false
    private var adjustEditTextMargin: Boolean? = false
    private var etContainer: LinearLayout? = null
    private var parentContainer: RelativeLayout? = null
    private var uibConnection: UIBConnection? = null
    private var supportChatAdapter: UIBChatAdapter? = null
    private var userMessageTextSize: Float? = 0.0f
    private var botMessageTextSize: Float? = 0.0f
    private var botMessageTextStyle: Int? = null
    private var userMessageTextStyle: Int? = null
    private var userMessageTextColor: Int? = null
    private var userMessageTextBackground: Drawable? = null
    private var botMessageTextColor: Int? = null
    private var botMessageTextBackground: Drawable? = null
    private var noDataTextVisibility: Int? = null
    private var noDataMessage: String? = null
    private var noDataMessageTextColor: Int? = null
    private var noDataMessageTextStyle: Int? = null
    private var noDataMessageTextSize: Float? = null
    private var adjustUserTextMargin: Boolean? = false
    private var adjustUserTextPadding: Boolean? = false
    private var adjustBotTextMargin: Boolean? = false
    private var adjustBotTextPadding: Boolean? = false
    private var userTextMarginRight: Int? = null
    private var botTextMarginRight: Int? = null
    private var userTextMarginLeft: Int? = null
    private var botTextMarginLeft: Int? = null
    private var userTextMarginTop: Int? = null
    private var botTextMarginTop: Int? = null
    private var userTextMarginBottom: Int? = null
    private var botTextMarginBottom: Int? = null
    private var userTextPaddingRight: Int? = null
    private var botTextPaddingRight: Int? = null
    private var userTextPaddingLeft: Int? = null
    private var botTextPaddingLeft: Int? = null
    private var userTextPaddingTop: Int? = null
    private var botTextPaddingTop: Int? = null
    private var userTextPaddingBottom: Int? = null
    private var botTextPaddingBottom: Int? = null
    private var appId: String? = null
    private var botId: String? = null
    private var userId: String? = null
    /*override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }*/

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mView = inflater.inflate(R.layout.fragment_uib_chat, container, false)
        //activity?.window?.setSoftInputMode(SOFT_INPUT_ADJUST_RESIZE)
        etMessage = mView?.findViewById(R.id.et_message)
        tvUserMessage = mView?.findViewById(R.id.tv_message_user)
        tvBotMessage = mView?.findViewById(R.id.tv_message_bot)
        rvChatList = mView?.findViewById(R.id.chat_recycler_view)
        sendMessage = mView?.findViewById(R.id.send)
        etContainer = mView?.findViewById(R.id.et_container)
        parentContainer = mView?.findViewById(R.id.parent_container)
        tvNoData = mView?.findViewById(R.id.tv_no_data)
        supportChatAdapter = UIBChatAdapter()
        rvChatList?.adapter = supportChatAdapter
        val layoutManager = LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false)
        //layoutManager.reverseLayout = true
        layoutManager.stackFromEnd = true
        rvChatList?.layoutManager = layoutManager
        sendMessage?.setOnClickListener(this)
        uibConnection = UIBConnection(uibEventListener = this)
        this.userId = UUID.randomUUID().toString()
        uibConnection?.connect(appId = this.appId!!, botId = this.botId!!, userId = this.userId!!)
        Log.d("Package_name", activity?.applicationContext?.packageName!!)

        /*Log.d(
            "Android_ID",
            Settings.Secure.getString(activity?.contentResolver, Settings.Secure.ANDROID_ID)
        )*/

        applyUIChanges()
        //Log.d("UUID", UUID.fromString(appId).toString())

        return mView
    }


    override fun setUIBSendIcon(icon: Drawable) {
        sendIcon = icon

    }

    override fun setUIBSendButtonBackground(background: Drawable) {
        this.sendButtonBackground = background
    }

    override fun setUIBEditTextHint(hint: String) {
        this.hint = hint
    }

    override fun setUIBEditTextBackground(background: Drawable) {
        this.editTextBackground = background
    }

    override fun setUIBEditTextInputType(inputType: Int) {
        editTextInputType = inputType
    }

    override fun setPaddingForEditText(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        adjustEditTextPadding = adjustPadding
        editTextLeftPadding = left
        editTextRightPadding = right
        editTextTopPadding = top
        editTextBottomPadding = bottom
    }


    override fun setMarginForEditText(
        adjustMargin: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        adjustEditTextMargin = adjustMargin
        editTextBottomMargin = bottom
        editTextLeftMargin = left
        editTextRightMargin = right
        editTextTopMargin = top

    }


    override fun showErrorMessageForEmptyValue(errorString: String) {
        this.errorMessage = errorString
    }

    override fun shouldShowErrorForEmptyMessage(value: Boolean) {
        this.shouldShowErrorMessage = value
    }

    override fun trimTypedMessage(value: Boolean) {
        this.trimTypedMessage = value
    }

    override fun setUIBEditTextHintColor(color: Int) {
        this.editTextHintColor = color
    }

    private fun applyUIChanges() {
        if (hint != null) {
            etMessage?.hint = hint
        }
        if (sendButtonBackground != null) {
            sendMessage?.background = sendButtonBackground

        }
        if (sendIcon != null) {
            sendMessage?.setCompoundDrawablesWithIntrinsicBounds(sendIcon, null, null, null)
        }
        if (editTextBackground != null) {
            etMessage?.background = editTextBackground
        }
        if (editTextInputType != null) {
            etMessage?.inputType = editTextInputType!!
        }
        if (errorMessage == null) {
            errorMessage = activity?.resources?.getString(R.string.error_msg_for_edit_text)
        }
        if (editTextHintColor != null) {
            etMessage?.setHintTextColor(editTextHintColor!!)
        }
        if (adjustEditTextPadding!!) {
            etMessage?.setPadding(
                editTextLeftPadding!!,
                editTextTopPadding!!,
                editTextRightPadding!!,
                editTextBottomPadding!!
            )
        }
        if (adjustEditTextMargin!!) {
            val params: ViewGroup.MarginLayoutParams =
                etContainer?.layoutParams as ViewGroup.MarginLayoutParams
            params.setMargins(
                editTextLeftMargin!!,
                editTextTopMargin!!,
                editTextRightMargin!!,
                editTextBottomMargin!!
            )
            if (editTextBottomMargin != 0)
                etContainer?.translationY = (-editTextBottomMargin?.toFloat()!!)
        }

        if (layoutBackground != null) {
            //etContainer?.background = layoutBackground
            parentContainer?.background = layoutBackground
        }
        if (userMessageTextSize != 0.0f) {
            supportChatAdapter?.setUserMessageTextSize(userMessageTextSize!!)
        }

        if (botMessageTextSize != 0.0f) {
            supportChatAdapter?.setBotMessageTextSize(botMessageTextSize!!)
        }

        if (userMessageTextStyle != null) {
            supportChatAdapter?.setUserMessageTextStyle(userMessageTextStyle!!)
        }

        if (botMessageTextStyle != null) {
            supportChatAdapter?.setBotMessageTextStyle(botMessageTextStyle!!)
        }

        if (userMessageTextColor != null) {
            supportChatAdapter?.setUserMessageTextColor(userMessageTextColor!!)
        }

        if (botMessageTextColor != null) {
            supportChatAdapter?.setBotMessageTextColor(botMessageTextColor!!)
        }

        if (userMessageTextBackground != null) {
            supportChatAdapter?.setUserMessageTextBackground(userMessageTextBackground!!)
        }


        if (botMessageTextBackground != null) {
            supportChatAdapter?.setSupportMessageTextBackground(botMessageTextBackground!!)
        }
        if (noDataMessage != null) {
            tvNoData?.text = noDataMessage
        }
        if (noDataMessageTextColor != null) {
            tvNoData?.setTextColor(noDataMessageTextColor!!)
        }

        if (noDataMessageTextStyle != null) {
            tvNoData?.setTypeface(tvNoData?.typeface, noDataMessageTextStyle!!)
        }
        if (noDataMessageTextSize != null) {
            tvNoData?.textSize = noDataMessageTextSize!!
        }
        if (noDataTextVisibility != null) {
            tvNoData?.visibility = noDataTextVisibility!!
        }
        if (adjustBotTextMargin!!) {
            supportChatAdapter?.setMarginForBotText(
                adjustMargin = adjustBotTextMargin!!,
                left = botTextMarginLeft!!,
                right = botTextMarginRight!!,
                top = botTextMarginTop!!,
                bottom = botTextMarginBottom!!
            )
        }

        if (adjustUserTextMargin!!) {
            supportChatAdapter?.setMarginForUserText(
                adjustMargin = adjustUserTextMargin!!,
                left = userTextMarginLeft!!,
                right = userTextMarginRight!!,
                top = userTextMarginTop!!,
                bottom = userTextMarginBottom!!
            )
        }

        if (adjustBotTextPadding!!) {
            supportChatAdapter?.setPaddingForBotText(
                adjustPadding = adjustBotTextPadding!!,
                left = botTextPaddingLeft!!,
                right = botTextPaddingRight!!,
                top = botTextPaddingTop!!,
                bottom = botTextPaddingBottom!!
            )
        }

        if (adjustUserTextPadding!!) {
            supportChatAdapter?.setPaddingForUserText(
                adjustPadding = adjustUserTextPadding!!,
                left = userTextPaddingLeft!!,
                right = userTextPaddingRight!!,
                top = userTextPaddingTop!!,
                bottom = userTextPaddingBottom!!
            )
        }

    }


    override fun onDestroyView() {
        mView = null
        etMessage = null
        hint = null
        sendIcon = null
        editTextBackground = null
        editTextInputType = null
        editTextLeftPadding = null
        editTextTopPadding = null
        editTextRightPadding = null
        editTextBottomPadding = null
        editTextLeftMargin = null
        editTextTopMargin = null
        editTextRightMargin = null
        editTextBottomMargin = null
        actionBarTitle = null
        errorMessage = null
        sendMessage = null
        shouldShowErrorMessage = null
        trimTypedMessage = null
        editTextHintColor = null
        layoutBackground = null
        supportChatAdapter = null
        userMessageTextSize = null
        botMessageTextSize = null
        userMessageTextStyle = null
        botMessageTextStyle = null
        userMessageTextBackground = null
        botMessageTextBackground = null
        userMessageTextColor = null
        botMessageTextColor = null
        tvNoData = null
        noDataMessage = null
        noDataMessageTextColor = null
        noDataMessageTextSize = null
        noDataMessageTextStyle = null
        userTextMarginBottom = null
        userTextMarginLeft = null
        userTextMarginRight = null
        userTextMarginTop = null
        userTextPaddingBottom = null
        userTextPaddingLeft = null
        userTextPaddingRight = null
        userTextPaddingTop = null
        botTextMarginBottom = null
        botTextMarginLeft = null
        botTextMarginRight = null
        botTextMarginTop = null
        botTextPaddingBottom = null
        botTextPaddingLeft = null
        botTextPaddingRight = null
        botTextPaddingTop = null
        adjustBotTextMargin = null
        adjustBotTextPadding = null
        adjustUserTextMargin = null
        adjustUserTextPadding = null
        appId = null
        botId = null
        userId = null
        noDataTextVisibility = null
        uibConnection?.disposeEventSource()
        super.onDestroyView()
    }

    override fun onClick(v: View?) {
        if (v?.id == R.id.send) {
            if (etMessage?.text.toString().trim().isNotEmpty()) {
                tvNoData?.visibility = View.GONE
                //val chatUser = DummyChat(etMessage?.text.toString().trim(), 0)
                //val chatBot = DummyChat("${etMessage?.text.toString().trim()}    -- BOT", 1)
                /*tvUserMessage?.text = messageFromUser()
                tvBotMessage?.text = messageFromUser()*/
                //supportChatAdapter?.addItem(chatUser)
                /*val message = MessageBody()
                val body = message.Message()
                body.text = etMessage?.text.toString().trim()
                body.type = "text"
                message.message = body*/
                val msgObject = JsonObject()
                val dataObject = JsonObject()
                val dataList = JsonArray()

                dataObject.addProperty("text", etMessage?.text.toString().trim())
                dataObject.addProperty("type", "text")
                dataList.add(dataObject)
                msgObject.add("message", dataList)
                val repo = PostMessageRepo(responseListener = this)
                repo.postMessage(
                    message = msgObject,
                    appId = this.appId!!,
                    botId = this.botId!!,
                    userId = this.userId!!
                )
                val chat = Chat(etMessage?.text.toString().trim(), 0)
                etMessage?.setText("")
                supportChatAdapter?.addItem(chat = chat)
                rvChatList?.smoothScrollToPosition(supportChatAdapter?.itemCount!!)
            } else {
                if (shouldShowErrorMessage!!) {
                    Toast.makeText(activity!!, errorMessage, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /*private fun messageFromUser(): String? {
        return if (trimTypedMessage!!) {
            etMessage?.text.toString().trim()
        } else {
            etMessage?.text.toString()
        }
    }*/

    override fun setBackGroundForLayout(background: Drawable) {
        this.layoutBackground = background
    }

    override fun setUserMessageTextSize(size: Float) {
        this.userMessageTextSize = size
    }

    override fun setUserMessageTextStyle(style: Int) {
        this.userMessageTextStyle = style
    }

    override fun setUserMessageTextColor(color: Int) {
        this.userMessageTextColor = color
    }

    override fun setUserMessageTextBackground(background: Drawable) {
        this.userMessageTextBackground = background
    }

    override fun setSupportMessageTextStyle(style: Int) {
        this.botMessageTextStyle = style
    }

    override fun setSupportMessageTextColor(color: Int) {
        this.botMessageTextColor = color
    }

    override fun setSupportMessageTextSize(size: Float) {
        this.botMessageTextSize = size
    }

    override fun setSupportMessageTextBackground(background: Drawable) {
        this.botMessageTextBackground = background
    }

    override fun setNoDataTextVisibility(visibility: Int) {
        this.noDataTextVisibility = visibility
    }

    override fun setNoDataText(value: String, textColor: Int, textStyle: Int, textSize: Float) {
        this.noDataMessage = value
        this.noDataMessageTextColor = textColor
        this.noDataMessageTextSize = textSize
        this.noDataMessageTextStyle = textStyle
    }

    override fun setMarginForUserText(
        adjustMargin: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustUserTextMargin = adjustMargin
        this.userTextMarginBottom = bottom
        this.userTextMarginLeft = left
        this.userTextMarginRight = right
        this.userTextMarginTop = top
    }

    override fun setPaddingForUserText(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustUserTextPadding = adjustPadding
        this.userTextPaddingTop = top
        this.userTextPaddingRight = right
        this.userTextPaddingLeft = left
        this.userTextPaddingBottom = bottom
    }

    override fun setMarginForSupportText(
        adjustMargin: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustBotTextMargin = adjustMargin
        this.botTextMarginTop = top
        this.botTextMarginRight = right
        this.botTextMarginLeft = left
        this.botTextMarginBottom = bottom
    }

    override fun setPaddingForSupportText(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    ) {
        this.adjustBotTextPadding = adjustPadding
        this.botTextPaddingBottom = bottom
        this.botTextPaddingLeft = left
        this.botTextPaddingRight = right
        this.botTextPaddingTop = top
    }

    override fun setAccountDetails(appId: String, botId: String, userId: String) {
        this.appId = appId
        //this.userId = userId
        this.botId = botId
    }

    override fun <T> onSuccess(response: T) {

    }

    override fun onError(error: Throwable) {

    }

    override fun <T> onEventResponse(response: T) {
        if (response is String) {
            val chat = Chat(response, 1)
            activity?.runOnUiThread {
                supportChatAdapter?.addItem(chat = chat)
                rvChatList?.smoothScrollToPosition(supportChatAdapter?.itemCount!!)
            }
        }
    }

    override fun onEventError(error: Exception) {

    }


}




