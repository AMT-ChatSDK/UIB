package com.unified.inbox

internal interface OnResponseListener {

    fun <T> onSuccess(response: T)
    fun onError(error: Throwable)
}