package com.unified.inbox

import android.graphics.drawable.Drawable

internal interface UIBListener {
    //fun sendMessage(message: String)

    fun setBackGroundForLayout(background: Drawable)
    fun setUserMessageTextSize(size: Float)
    fun setUserMessageTextStyle(style: Int)
    fun setUserMessageTextColor(color: Int)
    fun setUserMessageTextBackground(background: Drawable)
    fun setSupportMessageTextStyle(style: Int)
    fun setSupportMessageTextColor(color: Int)
    fun setSupportMessageTextSize(size: Float)
    fun setSupportMessageTextBackground(background: Drawable)
    fun setNoDataTextVisibility(visibility: Int)
    fun setNoDataText(value: String, textColor: Int, textStyle: Int, textSize: Float)
    fun setMarginForUserText(adjustMargin: Boolean, left: Int, right: Int, top: Int, bottom: Int)
    fun setPaddingForUserText(adjustPadding: Boolean, left: Int, right: Int, top: Int, bottom: Int)
    fun setMarginForSupportText(adjustMargin: Boolean, left: Int, right: Int, top: Int, bottom: Int)
    fun setPaddingForSupportText(
        adjustPadding: Boolean,
        left: Int,
        right: Int,
        top: Int,
        bottom: Int
    )

    fun setAccountDetails(appId: String, botId: String, userId: String)
}