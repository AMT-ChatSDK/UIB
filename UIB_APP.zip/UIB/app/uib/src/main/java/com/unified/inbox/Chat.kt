package com.unified.inbox

data class Chat(var msg: String, var from: Int)