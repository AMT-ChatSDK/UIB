package com.unified.inbox


import com.google.gson.annotations.SerializedName


data class PostMessageResponse(

    @field:SerializedName("status")
    val status: Int? = null
)